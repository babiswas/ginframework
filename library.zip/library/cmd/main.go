package main

import (
	"library/books"
	"library/common/db"

	"github.com/gin-gonic/gin"
)

func main() {
	dbUrl := "host=localhost user=postgres password=learner#12 dbname=newapp port=5432"
	port := ":9123"

	router := gin.Default()
	dbHandler := db.Init(dbUrl)

	books.RegisterRoutes(router, dbHandler)

	router.GET("/", func(ctx *gin.Context) {
		ctx.JSON(200, gin.H{
			"port":  port,
			"dbUrl": dbUrl,
		})
	})

	router.Run(port)
}
