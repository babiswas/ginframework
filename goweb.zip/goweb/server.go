package main

import (
	"goweb/Controller"
	"goweb/DB"
	"log"

	"github.com/gin-gonic/gin"
)

func main() {
	log.Println("Creating a router.")
	router := gin.Default()

	log.Println("Starting db migration.")
	DB.Migration()

	log.Println("Creating routers and handlers.")
	router.POST("/user", Controller.Create_user)
	router.GET("/all_user", Controller.Get_all_user)
	router.GET("/user/:userid", Controller.Get_user_by_id)

	log.Println("Running the server on port 9123.")
	err := router.Run(":9123")

	if err != nil {
		log.Fatal(err)
	}
}
