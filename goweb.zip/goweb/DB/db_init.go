package DB

import (
	"fmt"
	usermodel "goweb/Model"
	"log"
	"os"

	"gorm.io/driver/postgres"
	"gorm.io/gorm"
)

func Get_db() (*gorm.DB, error) {
	dsn := "host=localhost user=postgres password=learner#12 dbname=newapp port=5432"
	db, err := gorm.Open(postgres.Open(dsn), &gorm.Config{})
	if err != nil {
		fmt.Println("Error Occured", err)
		return db, err
	}
	return db, nil
}

func handle_err(err error) {
	if err != nil {
		fmt.Println(err)
		log.Fatal(err)
		os.Exit(1)
	}
}

func Migration() *gorm.DB {
	db, err := Get_db()
	handle_err(err)
	db.AutoMigrate(&usermodel.User{})
	return db
}
