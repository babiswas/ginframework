package Controller

import (
	"goweb/DB"
	"goweb/Model"
	"log"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

func Create_user(c *gin.Context) {
	log.Println("Creating a empty user model.")
	user := Model.User{}

	log.Println("Populating the empty user model.")
	if err := c.BindJSON(&user); err != nil {
		c.AbortWithError(http.StatusBadRequest, err)
		return
	}

	log.Println("Getting the db connection.")
	db, err := DB.Get_db()
	if err != nil {
		log.Fatal(err)
	}

	log.Println("Creating db entry for the user.")
	db.Create(&user)

	log.Println("Returning the data in json format.")
	c.JSON(http.StatusAccepted, &user)
}

func Get_all_user(c *gin.Context) {
	log.Println("Creating an empty user model list.")
	all_users := []Model.User{}

	log.Println("Creating a database connection.")
	db, err := DB.Get_db()
	if err != nil {
		log.Fatal(err)
	}

	log.Println("Quering the db for list of users.")
	db.Select("name", "phone").Find(&all_users)

	log.Println("Returning the data in json format.")
	c.JSON(http.StatusOK, &all_users)
}

func Get_user_by_id(c *gin.Context) {
	log.Println("Creating an empty user model.")
	user := Model.User{}

	log.Println("Fetching the user id from the request.")
	userid := c.Param("userid")

	log.Println("Getting the db connections.")
	db, err := DB.Get_db()
	if err != nil {
		log.Fatal(err)
	}
	userid_int, err := strconv.Atoi(userid)
	if err != nil {
		log.Fatal(err)
	}

	log.Println("Getting the data from database.")
	db.First(&user, userid_int)

	log.Println("Returning the data in json format.")
	c.JSON(http.StatusOK, &user)
}
